// MusicPDF - Copyright © Ignazio Paolicelli
const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');

function crea() {
  const w = new BrowserWindow({
    width: 1200, height: 900, minWidth: 420, minHeight: 500,
    title: 'MusicPDF', icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true, backgroundColor: '#fff8ec',
    webPreferences: { contextIsolation: true, spellcheck: false }
  });
  w.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); shell.openExternal(url); } });
  w.loadFile(path.join(__dirname, 'www', 'index.html'));
}

if (process.platform !== 'darwin') Menu.setApplicationMenu(null);
app.whenReady().then(crea);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) crea(); });
